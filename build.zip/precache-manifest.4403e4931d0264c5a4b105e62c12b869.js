self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "62590d43c8be86989230a8b953cc4fd2",
    "url": "/index.html"
  },
  {
    "revision": "df5cacf84cd12529185e",
    "url": "/static/css/2.8e81ebd9.chunk.css"
  },
  {
    "revision": "99ad777104f1ce4b39da",
    "url": "/static/css/main.21c19627.chunk.css"
  },
  {
    "revision": "df5cacf84cd12529185e",
    "url": "/static/js/2.43a78438.chunk.js"
  },
  {
    "revision": "fd72cd659757c6709c488461185f5137",
    "url": "/static/js/2.43a78438.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e29669bd0331599b507d",
    "url": "/static/js/3.4bf50959.chunk.js"
  },
  {
    "revision": "5429808f0d6371661756",
    "url": "/static/js/4.3cd31a8f.chunk.js"
  },
  {
    "revision": "99ad777104f1ce4b39da",
    "url": "/static/js/main.96601ffd.chunk.js"
  },
  {
    "revision": "4e0e34f265fae8f33b01b27ae29d9d6f",
    "url": "/static/js/main.96601ffd.chunk.js.LICENSE.txt"
  },
  {
    "revision": "be9765c38c7b1e7f9d53",
    "url": "/static/js/runtime-main.68efd67b.js"
  },
  {
    "revision": "270f72df47e036d9cfa11f91f0a94a60",
    "url": "/static/media/arrow_left.270f72df.svg"
  },
  {
    "revision": "d9ccc77c8240ad0dc2724cf333c0479e",
    "url": "/static/media/arrow_right.d9ccc77c.svg"
  },
  {
    "revision": "5c58d0e1d2ec48e766846af99eaeb6f8",
    "url": "/static/media/flags.ae531914.png"
  },
  {
    "revision": "27670c535824abb6ae7263d60fdc8a86",
    "url": "/static/media/flags@2x.140042eb.png"
  }
]);