self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ec7ec23dec9dc32d3e9551bcf2ab1dc2",
    "url": "/index.html"
  },
  {
    "revision": "101e800bf0765d7c9d05",
    "url": "/static/css/2.8e81ebd9.chunk.css"
  },
  {
    "revision": "5a8020ea0472090aad14",
    "url": "/static/css/main.0ee0dbd3.chunk.css"
  },
  {
    "revision": "101e800bf0765d7c9d05",
    "url": "/static/js/2.f4d3f43e.chunk.js"
  },
  {
    "revision": "fd72cd659757c6709c488461185f5137",
    "url": "/static/js/2.f4d3f43e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "64c84b1ca01d0f2f835e",
    "url": "/static/js/3.291116f0.chunk.js"
  },
  {
    "revision": "50af4b2bc3880857bd91",
    "url": "/static/js/4.e15c5a2b.chunk.js"
  },
  {
    "revision": "5a8020ea0472090aad14",
    "url": "/static/js/main.2fde1c11.chunk.js"
  },
  {
    "revision": "4e0e34f265fae8f33b01b27ae29d9d6f",
    "url": "/static/js/main.2fde1c11.chunk.js.LICENSE.txt"
  },
  {
    "revision": "31cabff0e83719e87f67",
    "url": "/static/js/runtime-main.4dea73c8.js"
  },
  {
    "revision": "270f72df47e036d9cfa11f91f0a94a60",
    "url": "/static/media/arrow_left.270f72df.svg"
  },
  {
    "revision": "d9ccc77c8240ad0dc2724cf333c0479e",
    "url": "/static/media/arrow_right.d9ccc77c.svg"
  },
  {
    "revision": "5c58d0e1d2ec48e766846af99eaeb6f8",
    "url": "/static/media/flags.ae531914.png"
  },
  {
    "revision": "27670c535824abb6ae7263d60fdc8a86",
    "url": "/static/media/flags@2x.140042eb.png"
  }
]);