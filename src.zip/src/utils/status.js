export default [
  {
    id: 1,
    status: "Active",
  },
  {
    id: 2,
    status: "Inactive",
  },
];
