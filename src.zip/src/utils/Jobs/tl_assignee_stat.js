export default [
  {
    value: "TL_ASSIGNED_FINAL_ASSIGNEE",
    label: "Team Lead Assigned Recruiter",
  },
];
