export default [
  {
    id: 1,
    siteName: "www.midaslegal.org",
  },
];
