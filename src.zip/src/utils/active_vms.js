export default [
  { id: 1, value: "Medefis5" },
  { id: 2, value: "Kruse" },
  { id: 3, value: "StafferLink" },
  { id: 4, value: "AHSA" },
  { id: 5, value: "MedicalSolutions" },
  { id: 6, value: "PeopleFluent" },
  { id: 7, value: "FieldGlass" },
  { id: 8, value: "ShiftWise" },
];
