import React from "react";

const NewHor = () => {
  return (
    <>
      <nav className="new-nav"></nav>
    </>
  );
};

export default NewHor;
