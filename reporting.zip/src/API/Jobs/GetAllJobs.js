import React from "react";
import { chost, host } from "../../static";

const GetAllJobs = (setAllJobs, setIsloading) => {
  const options = {
    method: "GET",
    mode: "cors",
  };
  // fetch(
  //   "https://jobfeed.jobrobotix.com/api/json/jobs/412C1B162551426C8EE8EF4C923ED8E4/default",
  //   options
  // )
  //   .then((response) => response.json())
  //   .then((response) => console.log(response.slice(0, 30)))
  //   .catch((err) => console.error(err));

  fetch(`${chost}jobs/get-jobs`, options)
    .then((response) => response.json())
    .then((response) => {
      console.log("response:", response);

      // if (response) {
      //   setAllJobs(response.source.job);
      //   setIsloading(false);
      // } else {
      //   setIsloading(true);
      // }
    })
    .catch((err) => console.error(err));
};

export default GetAllJobs;
/* response.source.job.map((item , index) =>  item["bill-rate-note"].replaceAll("![CDATA["  , "").replaceAll("]]" , "").replaceAll("!" , ""))); */
